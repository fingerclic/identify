import bcrypt from 'bcryptjs';

export interface SeedData {
  superAdmin: {
    id: string;
    email: string;
    fullName: string;
    phone: string;
    bio: string;
    role: string;
    emailVerified: boolean;
    language: string;
    timezone: string;
    address: string;
    city: string;
    country: string;
    company: string;
    jobTitle: string;
  };
  apps: Array<{
    id: string;
    code: string;
    name: string;
    description: string;
    url: string;
    iconName: string;
    color: string;
    isSystem: boolean;
  }>;
}

export const seedData: SeedData = {
  superAdmin: {
    id: 'usr_fingerclic_master_001',
    email: 'fingerclic@gmail.com',
    fullName: 'Alexandre Fingerclic',
    phone: '+33 6 12 34 56 78',
    bio: 'Super Admin & Fondateur de l\'écosystème Fingerclic Identify',
    role: 'SUPER_ADMIN',
    emailVerified: true,
    language: 'fr',
    timezone: 'Europe/Paris',
    address: '15 Avenue des Champs-Élysées',
    city: 'Paris',
    country: 'France',
    company: 'Fingerclic Technologies',
    jobTitle: 'Chief Identity Officer'
  },
  apps: [
    {
      id: 'app_marketplace',
      code: 'MARKETPLACE',
      name: 'Marketplace',
      description: 'Achat et vente de services, assets et ressources numériques Fingerclic',
      url: 'https://marketplace.fingerclic.com',
      iconName: 'ShoppingBag',
      color: '#3B82F6',
      isSystem: true
    },
    {
      id: 'app_creator',
      code: 'CREATOR',
      name: 'Creator Studio',
      description: 'Plateforme d\'édition, monétisation et diffusion de contenus pour créateurs',
      url: 'https://creator.fingerclic.com',
      iconName: 'Video',
      color: '#8B5CF6',
      isSystem: true
    },
    {
      id: 'app_admin',
      code: 'ADMIN',
      name: 'Admin Central',
      description: 'Supervision globale, modération et gestion de la communauté',
      url: 'https://admin.fingerclic.com',
      iconName: 'ShieldCheck',
      color: '#EF4444',
      isSystem: true
    },
    {
      id: 'app_habitat',
      code: 'HABITAT',
      name: 'Habitat',
      description: 'Gestion immobilière, réservation de résidences et espaces collaboratifs',
      url: 'https://habitat.fingerclic.com',
      iconName: 'Home',
      color: '#10B981',
      isSystem: true
    },
    {
      id: 'app_academy',
      code: 'ACADEMY',
      name: 'Academy',
      description: 'E-learning, certifications professionnelles et parcours de compétences',
      url: 'https://academy.fingerclic.com',
      iconName: 'GraduationCap',
      color: '#F59E0B',
      isSystem: true
    },
    {
      id: 'app_organisation',
      code: 'ORGANISATION',
      name: 'Organisation',
      description: 'Gestion d\'entreprises, équipes, rôles et espaces de travail',
      url: 'https://org.fingerclic.com',
      iconName: 'Building2',
      color: '#6366F1',
      isSystem: true
    },
    {
      id: 'app_fip',
      code: 'FIP',
      name: 'FIP (Finances)',
      description: 'Financement participatif, investissement et suivi des transactions',
      url: 'https://fip.fingerclic.com',
      iconName: 'TrendingUp',
      color: '#EC4899',
      isSystem: true
    },
    {
      id: 'app_website',
      code: 'WEBSITE',
      name: 'Portail Officiel',
      description: 'Portail institutionnel et vitrine globale Fingerclic',
      url: 'https://fingerclic.com',
      iconName: 'Globe',
      color: '#06B6D4',
      isSystem: true
    }
  ]
};
